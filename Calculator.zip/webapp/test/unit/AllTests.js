sap.ui.define([
	"comhcl/calc/test/unit/controller/calcu.controller"
], function () {
	"use strict";
});