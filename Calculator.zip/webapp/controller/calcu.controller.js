sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/NumberFormat"
], function (Controller, NumberFormat) {
	"use strict";

	return Controller.extend("comhcl.calc.controller.calcu", {
			onInit: function () {
				
			},
			
			onBtnPress1: function () {
				var num1 = this.getView().byId("firOne").getValue();
				var num2 = this.getView().byId("secTwo").getValue();
				// "NumberFormat" required from module "sap/ui/core/format/NumberFormat"
				var oFloatFormat = NumberFormat.getFloatInstance();
				 var f1 = oFloatFormat.parse(num1); 
				 var f2 = oFloatFormat.parse(num2); 
				this.getView().byId("resNew").setValue(f1 + f2);
			},
			onBtnPress2: function() {
				var num1 = this.getView().byId("firOne").getValue();
				var num2 = this.getView().byId("secTwo").getValue();
				var oFloatFormat = NumberFormat.getFloatInstance();
				var f1 = oFloatFormat.parse(num1);
				var f2 = oFloatFormat.parse(num2);
				this.getView().byId("resNew").setValue(f1 - f2);
			},
				onBtnPress3: function() {
				var num1 = this.getView().byId("firOne").getValue();
				var num2 = this.getView().byId("secTwo").getValue();
				var oFloatFormat = NumberFormat.getFloatInstance();
				var f1 = oFloatFormat.parse(num1);
				var f2 = oFloatFormat.parse(num2);
				this.getView().byId("resNew").setValue(f1 * f2);
			},
				onBtnPress4: function() {
				var num1 = this.getView().byId("firOne").getValue();
				var num2 = this.getView().byId("secTwo").getValue();
				var oFloatFormat = NumberFormat.getFloatInstance();
				var f1 = oFloatFormat.parse(num1);
				var f2 = oFloatFormat.parse(num2);
				this.getView().byId("resNew").setValue(f1 / f2);
			}
	});
});